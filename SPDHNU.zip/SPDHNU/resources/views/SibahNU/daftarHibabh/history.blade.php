<div class="tab-pane fade" id="pills-history" role="tabpanel" aria-labelledby="history-tab">
    <!-- Table with stripped rows -->

    <table class="table">
      <thead>
        <tr>
          <th scope="col">No</th>
          <th scope="col">Jenis</th>
          <th scope="col">Keterangan</th>
          <th scope="col">Tanggal</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>Pengajuan</td>
          <td>Pengajuan Dana Hibah</td>
          <td>12 Juni 2023</td>
        </tr>
      </tbody>
    </table>
    <!-- End Table with stripped rows -->
  </div>
</div>
